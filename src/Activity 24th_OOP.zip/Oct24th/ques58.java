package Oct24th;

public class ques58 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int[] array1 = {2, 4, 6, 8, 10};
	        int[] array2 = {4, 6, 8, 12, 14};


	        for (int element1 : array1) {
	            for (int element2 : array2) {
	                if (element1 ==(element2)) {
	                    System.out.println("Common element: " + element1);

	}

}
	        }
	}
}
