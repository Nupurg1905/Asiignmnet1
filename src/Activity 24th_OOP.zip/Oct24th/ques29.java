package Oct24th;

public class ques29 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int count = 1;
        
        while (count <= 10) {
            System.out.println(count);
            count++;

	}
	}
}

